package teste;

public class Teste {
	public String testar(){
		return "Testar!";
	}
}
